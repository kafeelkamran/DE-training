def greet(name:str):
    return (f"Habibi, Ahlan wa sahlan-> Aaiye janab, Khushamadidh {name}: Kafeel")